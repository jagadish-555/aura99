Chalk Line Font

The Chalk Line font is a chalk-like outline font designed by me. This font may be heavy to load. The font is based on Linux Biolinum Bold. I created this font using Fontographer 5 and Adobe Illustrator. Like all other fonts, this font is available in TrueType and OpenType formats, and it is in the public domain.

Check out other JLH Fonts, such as:

- Hand Drawn Shapes
- Grunge Handwriting
- Portmanteau
- Pretzel
- Marker Scribbles
- The Radical Sign
- The Jewish Bitmap
- Seattle Avenue